console.log('Nic tu nie ma 😱')
